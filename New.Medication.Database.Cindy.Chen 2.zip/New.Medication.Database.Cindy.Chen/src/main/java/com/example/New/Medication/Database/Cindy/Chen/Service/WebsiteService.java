package com.example.New.Medication.Database.Cindy.Chen.Service;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.example.New.Medication.Database.Cindy.Chen.Entity.Medication;
//import com.example.New.Medication.Database.Cindy.Chen.Entity.Website;
//import com.example.New.Medication.Database.Cindy.Chen.Repository.MedicationRepository;
//import com.example.New.Medication.Database.Cindy.Chen.Repository.WebsiteRepository;
//@Service
//@Transactional
//public class WebsiteService {
//	@Autowired
//	private WebsiteRepository websiteRepository;
//	
//	public Iterable<Website> listAll(){
//		return websiteRepository.findAll();
//	}
//}


